SingleDataset
=============

.. currentmodule:: daart.data

.. autoclass:: SingleDataset
   :show-inheritance:
