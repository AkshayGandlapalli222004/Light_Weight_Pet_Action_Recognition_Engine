PseudoLabels
============

.. currentmodule:: daart.callbacks

.. autoclass:: PseudoLabels
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~PseudoLabels.on_epoch_end

   .. rubric:: Methods Documentation

   .. automethod:: on_epoch_end
