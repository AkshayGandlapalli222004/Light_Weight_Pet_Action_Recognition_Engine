Transform
=========

.. currentmodule:: daart.transforms

.. autoclass:: Transform
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~Transform.__call__

   .. rubric:: Methods Documentation

   .. automethod:: __call__
