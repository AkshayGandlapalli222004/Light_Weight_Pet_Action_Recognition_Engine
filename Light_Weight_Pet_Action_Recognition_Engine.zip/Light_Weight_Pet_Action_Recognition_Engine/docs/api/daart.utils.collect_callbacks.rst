collect_callbacks
=================

.. currentmodule:: daart.utils

.. autofunction:: collect_callbacks
