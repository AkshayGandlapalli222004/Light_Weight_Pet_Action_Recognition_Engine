load_label_pkl
==============

.. currentmodule:: daart.data

.. autofunction:: load_label_pkl
