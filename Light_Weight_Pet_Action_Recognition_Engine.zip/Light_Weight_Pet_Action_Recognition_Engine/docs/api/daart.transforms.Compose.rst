Compose
=======

.. currentmodule:: daart.transforms

.. autoclass:: Compose
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~Compose.__call__

   .. rubric:: Methods Documentation

   .. automethod:: __call__
