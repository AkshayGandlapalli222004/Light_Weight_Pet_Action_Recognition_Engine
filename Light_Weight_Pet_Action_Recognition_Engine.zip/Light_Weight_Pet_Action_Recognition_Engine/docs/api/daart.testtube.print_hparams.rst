print_hparams
=============

.. currentmodule:: daart.testtube

.. autofunction:: print_hparams
