clean_tt_dir
============

.. currentmodule:: daart.testtube

.. autofunction:: clean_tt_dir
