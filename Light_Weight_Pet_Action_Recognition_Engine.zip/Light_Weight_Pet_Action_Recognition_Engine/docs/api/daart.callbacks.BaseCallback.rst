BaseCallback
============

.. currentmodule:: daart.callbacks

.. autoclass:: BaseCallback
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~BaseCallback.on_epoch_end

   .. rubric:: Methods Documentation

   .. automethod:: on_epoch_end
