Unitize
=======

.. currentmodule:: daart.transforms

.. autoclass:: Unitize
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~Unitize.__call__

   .. rubric:: Methods Documentation

   .. automethod:: __call__
