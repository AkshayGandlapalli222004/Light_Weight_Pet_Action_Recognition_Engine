Segmenter
=========

.. currentmodule:: daart.models.base

.. autoclass:: Segmenter
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~Segmenter.build_model
      ~Segmenter.forward
      ~Segmenter.predict_labels
      ~Segmenter.training_step

   .. rubric:: Methods Documentation

   .. automethod:: build_model
   .. automethod:: forward
   .. automethod:: predict_labels
   .. automethod:: training_step
