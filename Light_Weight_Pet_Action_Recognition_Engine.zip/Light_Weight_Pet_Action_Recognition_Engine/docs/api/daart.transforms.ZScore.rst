ZScore
======

.. currentmodule:: daart.transforms

.. autoclass:: ZScore
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~ZScore.__call__

   .. rubric:: Methods Documentation

   .. automethod:: __call__
