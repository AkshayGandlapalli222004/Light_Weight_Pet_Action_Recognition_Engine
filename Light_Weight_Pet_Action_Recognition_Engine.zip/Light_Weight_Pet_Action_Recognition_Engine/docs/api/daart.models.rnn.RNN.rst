RNN
===

.. currentmodule:: daart.models.rnn

.. autoclass:: RNN
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~RNN.forward

   .. rubric:: Methods Documentation

   .. automethod:: forward
