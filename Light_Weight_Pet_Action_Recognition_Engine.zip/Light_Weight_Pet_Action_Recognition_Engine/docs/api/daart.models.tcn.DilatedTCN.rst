DilatedTCN
==========

.. currentmodule:: daart.models.tcn

.. autoclass:: DilatedTCN
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~DilatedTCN.build_decoder
      ~DilatedTCN.build_encoder
      ~DilatedTCN.forward

   .. rubric:: Methods Documentation

   .. automethod:: build_decoder
   .. automethod:: build_encoder
   .. automethod:: forward
