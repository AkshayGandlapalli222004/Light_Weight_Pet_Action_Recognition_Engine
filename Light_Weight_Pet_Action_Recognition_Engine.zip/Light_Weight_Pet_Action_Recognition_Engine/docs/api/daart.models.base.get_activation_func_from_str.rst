get_activation_func_from_str
============================

.. currentmodule:: daart.models.base

.. autofunction:: get_activation_func_from_str
