load_marker_h5
==============

.. currentmodule:: daart.data

.. autofunction:: load_marker_h5
