build_data_generator
====================

.. currentmodule:: daart.utils

.. autofunction:: build_data_generator
