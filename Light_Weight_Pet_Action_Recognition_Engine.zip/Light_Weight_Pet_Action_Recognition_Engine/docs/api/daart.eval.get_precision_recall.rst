get_precision_recall
====================

.. currentmodule:: daart.eval

.. autofunction:: get_precision_recall
