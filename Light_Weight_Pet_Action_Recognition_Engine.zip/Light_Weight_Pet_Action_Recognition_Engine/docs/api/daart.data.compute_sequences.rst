compute_sequences
=================

.. currentmodule:: daart.data

.. autofunction:: compute_sequences
