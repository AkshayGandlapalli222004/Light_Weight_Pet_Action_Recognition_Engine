get_subdirs
===========

.. currentmodule:: daart.io

.. autofunction:: get_subdirs
