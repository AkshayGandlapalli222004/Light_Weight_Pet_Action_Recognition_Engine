create_tt_experiment
====================

.. currentmodule:: daart.testtube

.. autofunction:: create_tt_experiment
