BlockShuffle
============

.. currentmodule:: daart.transforms

.. autoclass:: BlockShuffle
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~BlockShuffle.__call__

   .. rubric:: Methods Documentation

   .. automethod:: __call__
