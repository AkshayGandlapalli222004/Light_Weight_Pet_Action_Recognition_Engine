EarlyStopping
=============

.. currentmodule:: daart.callbacks

.. autoclass:: EarlyStopping
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~EarlyStopping.on_epoch_end

   .. rubric:: Methods Documentation

   .. automethod:: on_epoch_end
