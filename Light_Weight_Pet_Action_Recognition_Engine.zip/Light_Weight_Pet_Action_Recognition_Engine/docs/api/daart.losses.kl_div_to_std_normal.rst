kl_div_to_std_normal
====================

.. currentmodule:: daart.losses

.. autofunction:: kl_div_to_std_normal
