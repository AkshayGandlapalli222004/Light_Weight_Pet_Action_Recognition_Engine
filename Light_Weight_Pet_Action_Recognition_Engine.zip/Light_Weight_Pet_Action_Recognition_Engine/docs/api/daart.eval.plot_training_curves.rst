plot_training_curves
====================

.. currentmodule:: daart.eval

.. autofunction:: plot_training_curves
