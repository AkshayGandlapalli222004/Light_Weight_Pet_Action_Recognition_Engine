MotionEnergy
============

.. currentmodule:: daart.transforms

.. autoclass:: MotionEnergy
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~MotionEnergy.__call__

   .. rubric:: Methods Documentation

   .. automethod:: __call__
