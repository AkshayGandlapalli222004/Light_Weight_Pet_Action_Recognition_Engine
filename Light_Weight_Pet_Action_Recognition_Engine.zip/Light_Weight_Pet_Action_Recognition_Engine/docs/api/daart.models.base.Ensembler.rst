Ensembler
=========

.. currentmodule:: daart.models.base

.. autoclass:: Ensembler
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~Ensembler.predict_labels

   .. rubric:: Methods Documentation

   .. automethod:: predict_labels
