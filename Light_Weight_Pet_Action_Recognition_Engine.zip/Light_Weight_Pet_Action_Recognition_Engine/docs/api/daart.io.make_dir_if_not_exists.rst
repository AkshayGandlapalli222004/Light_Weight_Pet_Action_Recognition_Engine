make_dir_if_not_exists
======================

.. currentmodule:: daart.io

.. autofunction:: make_dir_if_not_exists
