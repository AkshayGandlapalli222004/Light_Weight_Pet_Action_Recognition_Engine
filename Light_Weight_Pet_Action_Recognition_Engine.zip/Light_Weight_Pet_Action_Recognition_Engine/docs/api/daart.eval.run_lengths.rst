run_lengths
===========

.. currentmodule:: daart.eval

.. autofunction:: run_lengths
