reparameterize_gaussian
=======================

.. currentmodule:: daart.models.base

.. autofunction:: reparameterize_gaussian
