get_all_params
==============

.. currentmodule:: daart.testtube

.. autofunction:: get_all_params
