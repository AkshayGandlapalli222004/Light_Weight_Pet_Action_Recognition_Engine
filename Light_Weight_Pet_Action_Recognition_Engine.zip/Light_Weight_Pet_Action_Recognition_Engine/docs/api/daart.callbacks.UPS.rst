UPS
===

.. currentmodule:: daart.callbacks

.. autoclass:: UPS
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~UPS.on_epoch_end

   .. rubric:: Methods Documentation

   .. automethod:: on_epoch_end
