get_model_params
================

.. currentmodule:: daart.io

.. autofunction:: get_model_params
