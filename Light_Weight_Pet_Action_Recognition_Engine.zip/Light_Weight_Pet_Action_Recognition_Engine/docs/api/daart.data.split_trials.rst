split_trials
============

.. currentmodule:: daart.data

.. autofunction:: split_trials
