AnnealHparam
============

.. currentmodule:: daart.callbacks

.. autoclass:: AnnealHparam
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~AnnealHparam.on_epoch_end

   .. rubric:: Methods Documentation

   .. automethod:: on_epoch_end
