MakeOneHot
==========

.. currentmodule:: daart.transforms

.. autoclass:: MakeOneHot
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~MakeOneHot.__call__

   .. rubric:: Methods Documentation

   .. automethod:: __call__
