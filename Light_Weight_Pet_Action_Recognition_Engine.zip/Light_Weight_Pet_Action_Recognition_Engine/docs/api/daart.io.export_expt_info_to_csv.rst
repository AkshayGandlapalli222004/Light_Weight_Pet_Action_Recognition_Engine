export_expt_info_to_csv
=======================

.. currentmodule:: daart.io

.. autofunction:: export_expt_info_to_csv
