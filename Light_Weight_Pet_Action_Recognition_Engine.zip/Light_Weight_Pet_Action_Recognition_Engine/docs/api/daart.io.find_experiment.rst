find_experiment
===============

.. currentmodule:: daart.io

.. autofunction:: find_experiment
