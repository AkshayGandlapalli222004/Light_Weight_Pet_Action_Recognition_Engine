get_model_dir
=============

.. currentmodule:: daart.io

.. autofunction:: get_model_dir
