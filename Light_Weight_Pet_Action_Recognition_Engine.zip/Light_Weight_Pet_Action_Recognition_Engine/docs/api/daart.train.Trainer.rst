Trainer
=======

.. currentmodule:: daart.train

.. autoclass:: Trainer
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~Trainer.fit

   .. rubric:: Methods Documentation

   .. automethod:: fit
