read_expt_info_from_csv
=======================

.. currentmodule:: daart.io

.. autofunction:: read_expt_info_from_csv
