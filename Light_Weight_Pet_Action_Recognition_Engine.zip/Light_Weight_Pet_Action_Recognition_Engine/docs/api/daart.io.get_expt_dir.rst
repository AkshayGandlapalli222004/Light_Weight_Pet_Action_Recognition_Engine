get_expt_dir
============

.. currentmodule:: daart.io

.. autofunction:: get_expt_dir
