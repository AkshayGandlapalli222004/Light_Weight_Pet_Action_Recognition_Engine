Logger
======

.. currentmodule:: daart.train

.. autoclass:: Logger
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~Logger.create_metric_row
      ~Logger.get_loss
      ~Logger.reset_metrics
      ~Logger.update_metrics

   .. rubric:: Methods Documentation

   .. automethod:: create_metric_row
   .. automethod:: get_loss
   .. automethod:: reset_metrics
   .. automethod:: update_metrics
