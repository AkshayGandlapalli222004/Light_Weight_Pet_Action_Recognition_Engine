DataGenerator
=============

.. currentmodule:: daart.data

.. autoclass:: DataGenerator
   :show-inheritance:

   .. rubric:: Methods Summary

   .. autosummary::

      ~DataGenerator.next_batch
      ~DataGenerator.reset_iterators

   .. rubric:: Methods Documentation

   .. automethod:: next_batch
   .. automethod:: reset_iterators
