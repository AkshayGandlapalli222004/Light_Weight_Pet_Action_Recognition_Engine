daart API
=========

.. toctree::
   :maxdepth: 1

   ../modules/daart
   ../modules/daart.models
