.. _daart_modules_models:

daart Models package
====================

.. automodapi:: daart.models.base
   :no-inheritance-diagram:

.. automodapi:: daart.models.rnn
   :no-inheritance-diagram:

.. automodapi:: daart.models.tcn
   :no-inheritance-diagram:

.. automodapi:: daart.models.temporalmlp
   :no-inheritance-diagram:
